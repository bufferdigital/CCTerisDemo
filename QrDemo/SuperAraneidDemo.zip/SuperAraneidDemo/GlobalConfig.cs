﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QrDemo.SuperAraneidDemo
{
    public class GlobalConfig
    {
        /// <summary>
        /// url
        /// </summary>
        public static string WebUrl = "";
        /// <summary>
        /// 文件存放地址
        /// </summary>
        public static string FloderUrl = @"D:\workdir\EnvDB\trunk\doc\备份\test\";

        public static string FloderMoUrl = "/resource/";
    }
}
