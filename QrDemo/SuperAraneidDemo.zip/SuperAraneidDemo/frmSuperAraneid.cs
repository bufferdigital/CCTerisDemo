﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QrDemo.SuperAraneidDemo
{
    public partial class frmSuperAraneid : Form
    {
     
        public frmSuperAraneid()
        {
            InitializeComponent();
        }      

        private void button1_Click(object sender, EventArgs e)
        {
            string url = StringHelper.GetPureUrl("http://www.588ku.com");
            GlobalConfig.WebUrl = url;
            HttpUrlWork work = new HttpUrlWork() { URL = url  };
           
            Task t = TaskHelperCopy.RunProgram(work);
            Task t1 = TaskHelperImage.RunProgram();
            //Task t = RunProgram();
            //t.Wait();
            //Console.ReadKey();
        }
    }
}
